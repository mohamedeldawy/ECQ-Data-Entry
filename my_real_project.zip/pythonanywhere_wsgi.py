import os
import sys

USERNAME = "MohamedEldawy"
PROJECT_HOME = f"/home/{USERNAME}/Quiz-PaperSummary-Dashboard"
PRIVATE_DATA_HOME = f"/home/{USERNAME}/.quality-dashboard"

os.environ.setdefault("QUALITY_DASHBOARD_DATA_DIR", PRIVATE_DATA_HOME)
os.environ.setdefault("QUALITY_DASHBOARD_COOKIE_SECURE", "1")

if PROJECT_HOME not in sys.path:
    sys.path.insert(0, PROJECT_HOME)

from app import app as application
