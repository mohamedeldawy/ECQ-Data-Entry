import os
import sys
from flask import Flask, render_template, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# Data directory setup
data_dir = os.environ.get("QUALITY_DASHBOARD_DATA_DIR", os.path.expanduser("~/.quality-dashboard"))
os.makedirs(data_dir, exist_ok=True)
db_path = os.path.join(data_dir, "dashboard.db")

app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'quality-dashboard-secret-key-2026'

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(50), default='manager')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "database": os.path.exists(db_path)})

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "init-db":
        with app.app_context():
            db.create_all()
            print("Database initialized successfully.")
    elif len(sys.argv) > 1 and sys.argv[1] == "create-manager":
        name = "Manager"
        email = "manager@elkheta.com"
        for i in range(len(sys.argv)):
            if sys.argv[i] == "--name" and i + 1 < len(sys.argv):
                name = sys.argv[i+1]
            elif sys.argv[i] == "--email" and i + 1 < len(sys.argv):
                email = sys.argv[i+1]
        
        with app.app_context():
            db.create_all()
            existing = User.query.filter_by(email=email).first()
            if not existing:
                u = User(name=name, email=email, role='manager')
                u.set_password('123456789')
                db.session.add(u)
                db.session.commit()
                print(f"Manager '{name}' ({email}) created with default password '123456789'.")
            else:
                print("Manager account already exists.")
    else:
        app.run(debug=True)
